import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qrscannig',
  templateUrl: './qrscannig.component.html',
  styleUrls: ['./qrscannig.component.css']
})
export class QRscannigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
